/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Rol;

public interface RolDao {
    public List<Rol> selectItems();
}
