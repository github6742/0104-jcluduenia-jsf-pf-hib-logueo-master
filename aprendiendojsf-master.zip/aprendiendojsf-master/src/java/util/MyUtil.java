/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author lude
 */
public class MyUtil {
    
    public static String baseurl()
    {
        return "http://localhost:8080/aprendiendojsf/";
    }

    public static String basepathlogin()
    {
        return "/aprendiendojsf/faces/";
    }
    
    public static String basepath()
    {
        return "/faces/views/";
    }
}