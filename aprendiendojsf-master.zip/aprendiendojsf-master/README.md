# aprendiendojsf

Tutorial Básico de Java Server Faces - Prime Faces


Base de Datos: lib/aprendiendojsf.sql
